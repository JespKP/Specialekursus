function SL_assemble_global!(K, dh, cellvalues1, cellvalues2, C_dil, C_dev)
    n_basefuncs = getnbasefunctions(cellvalues2)
    ke = zeros(n_basefuncs, n_basefuncs)
    assembler = start_assemble(K)
    
    for cell in CellIterator(dh)
        reinit!(cellvalues1, cell)
        reinit!(cellvalues2, cell)
        fill!(ke, 0.0)
        JespersPackage.SL_assemble_cell!(ke, cellvalues1, cellvalues2, C_dil, C_dev)
        assemble!(assembler, celldofs(cell), ke)
    end
    return K
end