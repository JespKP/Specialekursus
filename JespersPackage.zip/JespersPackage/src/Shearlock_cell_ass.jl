function SL_assemble_cell!(ke, cellvalues_dil, cellvalues_dev, C_dil, C_dev)
    for q_point in 1:getnquadpoints(cellvalues_dil)
        dΩ = getdetJdV(cellvalues_dil, q_point)
        for i in 1:getnbasefunctions(cellvalues_dil)
            ∇Nᵢ = shape_gradient(cellvalues_dil, q_point, i)
            for j in 1:getnbasefunctions(cellvalues_dil)
                ∇Nⱼ = shape_gradient(cellvalues_dil, q_point, j)
                ∇ˢʸᵐNⱼ = symmetric(∇Nⱼ)
                ke[i, j] += (∇Nᵢ ⊡ C_dil ⊡ ∇ˢʸᵐNⱼ) * dΩ
            end
        end
    end
     for q_point in 1:getnquadpoints(cellvalues_dev)
        dΩ = getdetJdV(cellvalues_dev, q_point)
        for i in 1:getnbasefunctions(cellvalues_dev)
            ∇Nᵢ = shape_gradient(cellvalues_dev, q_point, i)
            for j in 1:getnbasefunctions(cellvalues_dev)
                ∇Nⱼ = shape_gradient(cellvalues_dev, q_point, j)
                ∇ˢʸᵐNⱼ = symmetric(∇Nⱼ)
                ke[i, j] += (∇Nᵢ ⊡ C_dev ⊡ ∇ˢʸᵐNⱼ) * dΩ
            end
        end
    end
    return ke
end