module JespersPackage
using Ferrite
using Tensors

include("External_traction.jl")
include("Shearlock_cell_ass.jl")
include("Shearlock_Glob_ass.jl")
include("Material_tensors.jl")
include("Von_mises.jl")

export assemble_external_forces!
export SL_assemble_cell!
export SL_assemble_global!
export plane_strain_tensors
export von_mises_from_plane_strain_3d
export cell_von_mises_plane_strain

end # module JespersPackage
